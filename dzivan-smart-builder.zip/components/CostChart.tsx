import React, { useMemo } from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend, BarChart, Bar, XAxis, YAxis, CartesianGrid } from 'recharts';
import { ProjectEstimate } from '../types';

interface CostChartProps {
  estimate: ProjectEstimate;
}

// Vibrant Colorful Palette for Charts
const COLORS = [
  '#eab308', // Yellow 500 (Gold)
  '#3b82f6', // Blue 500
  '#ec4899', // Pink 500
  '#10b981', // Emerald 500
  '#8b5cf6', // Violet 500
  '#f97316', // Orange 500
  '#06b6d4', // Cyan 500
  '#6366f1', // Indigo 500
];

const CostChart: React.FC<CostChartProps> = ({ estimate }) => {
  
  const categoryData = useMemo(() => {
    const categories: Record<string, number> = {};
    estimate.items.forEach(item => {
      categories[item.category] = (categories[item.category] || 0) + item.totalPrice;
    });
    
    // Add labor as a category for the visual
    categories['Labor'] = estimate.laborCostEstimate;

    return Object.entries(categories).map(([name, value]) => ({ name, value }));
  }, [estimate]);

  const currencyFormatter = (value: number) => 
    new Intl.NumberFormat('en-GH', { style: 'currency', currency: estimate.currency || 'GHS' }).format(value);

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
      {/* Distribution Chart */}
      <div className="bg-neutral-900 p-6 rounded-2xl shadow-lg border border-neutral-800 relative overflow-hidden">
         {/* Subtle colored glow */}
        <div className="absolute top-0 right-0 w-32 h-32 bg-blue-500/5 rounded-full blur-3xl -mr-10 -mt-10 pointer-events-none"></div>
        
        <h3 className="text-lg font-bold text-white mb-6 flex items-center gap-2 relative z-10">
          <span className="w-1.5 h-6 bg-blue-500 rounded-full"></span>
          Cost Distribution
        </h3>
        <div className="h-72 w-full relative z-10">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={categoryData}
                cx="50%"
                cy="50%"
                innerRadius={65}
                outerRadius={90}
                paddingAngle={4}
                dataKey="value"
                stroke="none"
              >
                {categoryData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip 
                formatter={(value: number) => currencyFormatter(value)}
                contentStyle={{ backgroundColor: '#171717', borderRadius: '12px', border: '1px solid #404040', color: '#fff' }} 
                itemStyle={{ color: '#fff' }}
              />
              <Legend verticalAlign="bottom" height={36} iconType="circle" wrapperStyle={{ color: '#a3a3a3' }} />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Breakdown Bar Chart */}
      <div className="bg-neutral-900 p-6 rounded-2xl shadow-lg border border-neutral-800 relative overflow-hidden">
        {/* Subtle colored glow */}
        <div className="absolute bottom-0 left-0 w-32 h-32 bg-purple-500/5 rounded-full blur-3xl -ml-10 -mb-10 pointer-events-none"></div>

        <h3 className="text-lg font-bold text-white mb-6 flex items-center gap-2 relative z-10">
          <span className="w-1.5 h-6 bg-purple-500 rounded-full"></span>
          Category Breakdown
        </h3>
        <div className="h-72 w-full relative z-10">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={categoryData} layout="vertical" margin={{ top: 5, right: 30, left: 40, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" horizontal={true} vertical={false} stroke="#262626" />
              <XAxis type="number" hide />
              <YAxis 
                type="category" 
                dataKey="name" 
                width={100} 
                tick={{fontSize: 12, fill: '#a3a3a3', fontWeight: 500}} 
                axisLine={false}
                tickLine={false}
              />
              <Tooltip 
                cursor={{fill: '#262626'}}
                formatter={(value: number) => currencyFormatter(value)} 
                contentStyle={{ backgroundColor: '#171717', borderRadius: '12px', border: '1px solid #404040', color: '#fff' }}
                itemStyle={{ color: '#fff' }}
              />
              <Bar dataKey="value" radius={[0, 6, 6, 0]}>
                {categoryData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};

export default CostChart;