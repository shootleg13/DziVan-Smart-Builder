import React, { useState, useMemo, useEffect } from 'react';
import { ProjectEstimate } from '../types';
import CostChart from './CostChart';
import { Download, MapPin, DollarSign, Hammer, AlertTriangle, Building2, Table, ArrowLeftRight, TrendingUp, TrendingDown, Minus, Filter } from 'lucide-react';
import { jsPDF } from "jspdf";
import autoTable from "jspdf-autotable";
import * as XLSX from "xlsx";

interface EstimateResultProps {
  estimate: ProjectEstimate;
  onReset: () => void;
}

const EstimateResult: React.FC<EstimateResultProps> = ({ estimate, onReset }) => {
  const [activeTab, setActiveTab] = useState<'summary' | 'materials'>('summary');
  const [isExportingPDF, setIsExportingPDF] = useState(false);
  const [isExportingExcel, setIsExportingExcel] = useState(false);
  
  // Track selected unit index for each item ID. 0 = default, 1+ = indices in alternates array
  const [unitSelections, setUnitSelections] = useState<Record<string, number>>({});
  
  // Filter state
  const [filterCategory, setFilterCategory] = useState<string>('All');

  // Reset filter when estimate changes
  useEffect(() => {
    setFilterCategory('All');
  }, [estimate]);

  const formatCurrency = (val: number) => 
    new Intl.NumberFormat('en-GH', { style: 'currency', currency: estimate.currency || 'GHS' }).format(val);

  // Helper to get the currently active unit details for an item
  const getItemDisplay = (item: typeof estimate.items[0]) => {
    const selection = unitSelections[item.id] || 0;
    if (selection === 0) {
      return {
        qty: item.quantity,
        unit: item.unit,
        price: item.unitPrice
      };
    }
    const altIndex = selection - 1;
    if (item.alternates && item.alternates[altIndex]) {
      return {
        qty: item.alternates[altIndex].quantity,
        unit: item.alternates[altIndex].unit,
        price: item.alternates[altIndex].unitPrice
      };
    }
    // Fallback
    return {
      qty: item.quantity,
      unit: item.unit,
      price: item.unitPrice
    };
  };

  const toggleUnit = (itemId: string, maxOptions: number) => {
    setUnitSelections(prev => {
      const current = prev[itemId] || 0;
      const next = (current + 1) % maxOptions;
      return { ...prev, [itemId]: next };
    });
  };

  // Identify top categories and simulate trends
  const marketTrends = useMemo(() => {
    const categoryTotals: Record<string, number> = {};
    estimate.items.forEach(item => {
      categoryTotals[item.category] = (categoryTotals[item.category] || 0) + item.totalPrice;
    });

    // Sort by cost desc and take top 4
    const topCategories = Object.entries(categoryTotals)
      .sort(([, a], [, b]) => b - a)
      .slice(0, 4)
      .map(([category]) => category);

    // Deterministic simulation based on category string
    return topCategories.map(category => {
      const hash = category.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);
      const types = ['up', 'down', 'stable'] as const;
      const type = types[hash % 3];
      const percentage = ((hash % 5) + 1) + '.' + (hash % 9);
      
      return { category, type, percentage };
    });
  }, [estimate.items]);

  // Derive unique categories for filter
  const uniqueCategories = useMemo(() => {
    const cats = new Set(estimate.items.map(item => item.category));
    return ['All', ...Array.from(cats).sort()];
  }, [estimate.items]);

  // Filter items based on selection
  const filteredItems = useMemo(() => {
    if (filterCategory === 'All') return estimate.items;
    return estimate.items.filter(item => item.category === filterCategory);
  }, [estimate.items, filterCategory]);

  const handleExportExcel = () => {
    setIsExportingExcel(true);
    try {
      const wb = XLSX.utils.book_new();
      
      // Sheet 1: Summary
      const summaryData = [
        ["Project Name", estimate.projectName],
        ["Location", estimate.location],
        ["Currency", estimate.currency],
        ["Date", new Date().toLocaleDateString()],
        [],
        ["Financial Overview", ""],
        ["Total Materials", estimate.totalMaterialCost],
        ["Labor Estimate", estimate.laborCostEstimate],
        ["Grand Total", estimate.grandTotal],
        [],
        ["Executive Summary", estimate.summary]
      ];
      const wsSummary = XLSX.utils.aoa_to_sheet(summaryData);
      
      // Basic formatting for Summary Sheet columns
      wsSummary['!cols'] = [{ wch: 20 }, { wch: 50 }];
      
      XLSX.utils.book_append_sheet(wb, wsSummary, "Summary");

      // Sheet 2: Detailed BOQ
      // We export ALL items regardless of current filter to provide a complete BOQ
      const boqHeader = ["Category", "Item Name", "Quantity", "Unit", "Unit Price", "Total Price", "Confidence", "Notes"];
      const boqData = estimate.items.map(item => {
        const display = getItemDisplay(item);
        return [
          item.category,
          item.name,
          display.qty,
          display.unit,
          display.price,
          item.totalPrice,
          item.confidence,
          item.notes || ""
        ];
      });
      const wsBoq = XLSX.utils.aoa_to_sheet([boqHeader, ...boqData]);
      
      // Set column widths for better readability
      wsBoq['!cols'] = [
        { wch: 15 }, // Category
        { wch: 30 }, // Item Name
        { wch: 10 }, // Quantity
        { wch: 10 }, // Unit
        { wch: 12 }, // Unit Price
        { wch: 12 }, // Total Price
        { wch: 10 }, // Confidence
        { wch: 40 }  // Notes
      ];

      XLSX.utils.book_append_sheet(wb, wsBoq, "Detailed BOQ");

      XLSX.writeFile(wb, `${(estimate.projectName || 'Estimate').replace(/\s+/g, '_')}_DziVan_Smart.xlsx`);

    } catch (error) {
      console.error("Excel Export Error:", error);
      alert("Failed to export Excel file.");
    } finally {
      setIsExportingExcel(false);
    }
  };

  const handleExportPDF = () => {
    setIsExportingPDF(true);
    try {
      const doc = new jsPDF();
      const pageWidth = doc.internal.pageSize.width;
      const pageHeight = doc.internal.pageSize.height;
      const margin = 14;
      const safeCurrency = (val: number) => `GHS ${val.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;

      doc.setFontSize(22);
      doc.setTextColor(234, 179, 8); // Gold color
      doc.text("DziVan Smart Builder", margin, 20);
      
      doc.setFontSize(10);
      doc.setTextColor(100);
      doc.text(`Generated on: ${new Date().toLocaleDateString()}`, pageWidth - margin, 20, { align: "right" });
      
      doc.setFontSize(14);
      doc.setTextColor(30);
      doc.text(estimate.projectName || "Construction Estimate", margin, 35);
      
      doc.setFontSize(10);
      doc.setTextColor(100);
      doc.text(`Location: ${estimate.location || 'Ghana'}`, margin, 41);

      doc.setFontSize(12);
      doc.setTextColor(0);
      doc.text("Project Summary", margin, 51);
      
      doc.setFontSize(10);
      doc.setTextColor(60);
      const summaryLines = doc.splitTextToSize(estimate.summary, pageWidth - 2 * margin);
      doc.text(summaryLines, margin, 57);

      let finalY = 57 + (summaryLines.length * 5);

      const tableBody = estimate.items.map(item => {
        const display = getItemDisplay(item);
        return [
          item.name,
          item.category,
          `${display.qty.toLocaleString()} ${display.unit}`,
          safeCurrency(display.price),
          safeCurrency(item.totalPrice),
          item.confidence
        ];
      });

      autoTable(doc, {
        startY: finalY + 10,
        head: [['Item', 'Category', 'Qty', 'Unit Price', 'Total', 'Conf.']],
        body: tableBody,
        headStyles: { fillColor: [202, 138, 4], textColor: 255 }, // Dark Gold
        alternateRowStyles: { fillColor: [254, 252, 232] }, // Light Yellow
        styles: { fontSize: 9, cellPadding: 3 },
        margin: { top: 20, bottom: 20 }
      });

      // @ts-ignore
      finalY = doc.lastAutoTable.finalY + 15;

      if (finalY > doc.internal.pageSize.height - 40) {
        doc.addPage();
        finalY = 20;
      }

      const rightColX = pageWidth - margin - 50;
      const valueColX = pageWidth - margin;

      doc.setFontSize(10);
      doc.setTextColor(60);
      doc.text("Total Materials:", rightColX, finalY);
      doc.text(safeCurrency(estimate.totalMaterialCost), valueColX, finalY, { align: "right" });
      
      finalY += 6;
      doc.text("Labor Estimate:", rightColX, finalY);
      doc.text(safeCurrency(estimate.laborCostEstimate), valueColX, finalY, { align: "right" });

      finalY += 10;
      doc.setFontSize(14);
      doc.setTextColor(0);
      doc.setFont("helvetica", "bold");
      doc.text("Grand Total:", rightColX, finalY);
      doc.text(safeCurrency(estimate.grandTotal), valueColX, finalY, { align: "right" });

      // Footer
      const pageCount = doc.getNumberOfPages();
      for(let i = 1; i <= pageCount; i++) {
        doc.setPage(i);
        doc.setFontSize(8);
        doc.setTextColor(150);
        doc.text(`Powered by DziVan Smart | Page ${i} of ${pageCount}`, pageWidth / 2, pageHeight - 10, { align: "center" });
      }

      doc.save(`${(estimate.projectName || 'Estimate').replace(/\s+/g, '_')}.pdf`);
    } catch (error) {
      console.error("PDF Export Error:", error);
      alert("Failed to generate PDF.");
    } finally {
      setIsExportingPDF(false);
    }
  };

  return (
    <div className="animate-fade-in pb-20">
      {/* Header Summary Card */}
      <div className="bg-neutral-900 rounded-2xl shadow-xl border border-neutral-800 p-6 mb-8 relative overflow-hidden">
        {/* Decorative background blob */}
        <div className="absolute top-0 right-0 -mr-20 -mt-20 w-80 h-80 rounded-full bg-gradient-to-br from-yellow-500/10 to-purple-500/10 blur-3xl pointer-events-none"></div>

        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8 relative z-10">
          <div>
            <h2 className="text-3xl font-bold text-white bg-clip-text text-transparent bg-gradient-to-r from-white to-neutral-400">
              {estimate.projectName || 'Construction Estimate'}
            </h2>
            <div className="flex flex-col sm:flex-row sm:items-center gap-2 sm:gap-4 mt-2">
              <div className="flex items-center gap-2 text-neutral-400">
                <MapPin className="w-5 h-5 text-blue-500" />
                <span className="text-sm font-medium">{estimate.location || 'Accra, Ghana'}</span>
              </div>
            </div>
          </div>
          <div className="flex gap-3 flex-wrap">
             <button onClick={onReset} className="px-5 py-2.5 text-sm font-semibold text-neutral-300 hover:text-white hover:bg-neutral-800 rounded-xl transition-colors">
              New Estimate
            </button>
            <button 
              onClick={handleExportExcel}
              disabled={isExportingExcel}
              className="flex items-center gap-2 px-5 py-2.5 bg-neutral-800 hover:bg-neutral-700 text-emerald-500 border border-emerald-500/30 text-sm font-semibold rounded-xl transition-all shadow-lg disabled:opacity-70 hover:shadow-emerald-900/20"
            >
              <Table className="w-4 h-4" />
              {isExportingExcel ? 'Exporting...' : 'Export Excel'}
            </button>
            <button 
              onClick={handleExportPDF}
              disabled={isExportingPDF}
              className="flex items-center gap-2 px-5 py-2.5 bg-gradient-to-r from-yellow-500 to-amber-500 hover:from-yellow-400 hover:to-amber-400 text-neutral-900 text-sm font-bold rounded-xl transition-all shadow-lg shadow-yellow-500/20 disabled:opacity-70"
            >
              <Download className="w-4 h-4" />
              {isExportingPDF ? 'Generating...' : 'Export PDF'}
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 relative z-10 mb-8">
          {/* Material Cost Card (Blue Theme) */}
          <div className="bg-neutral-800/50 backdrop-blur-sm border border-blue-500/20 p-5 rounded-xl text-white shadow-lg shadow-blue-900/10 transform hover:-translate-y-1 transition-transform duration-200">
            <div className="flex items-center gap-3 mb-3">
              <div className="p-2 bg-blue-500/20 rounded-lg">
                <Building2 className="w-5 h-5 text-blue-400" />
              </div>
              <span className="text-sm font-medium text-blue-200/70">Total Materials</span>
            </div>
            <p className="text-3xl font-bold tracking-tight text-white">{formatCurrency(estimate.totalMaterialCost)}</p>
          </div>

          {/* Labor Cost Card (Purple Theme) */}
          <div className="bg-neutral-800/50 backdrop-blur-sm border border-purple-500/20 p-5 rounded-xl text-white shadow-lg shadow-purple-900/10 transform hover:-translate-y-1 transition-transform duration-200">
            <div className="flex items-center gap-3 mb-3">
              <div className="p-2 bg-purple-500/20 rounded-lg">
                <Hammer className="w-5 h-5 text-purple-400" />
              </div>
              <span className="text-sm font-medium text-purple-200/70">Labor Estimate</span>
            </div>
            <p className="text-3xl font-bold tracking-tight text-white">{formatCurrency(estimate.laborCostEstimate)}</p>
          </div>

          {/* Grand Total Card (Gold Theme) */}
          <div className="bg-gradient-to-br from-yellow-500 to-amber-600 p-5 rounded-xl text-neutral-900 shadow-lg shadow-yellow-500/20 transform hover:-translate-y-1 transition-transform duration-200">
             <div className="flex items-center gap-3 mb-3">
              <div className="p-2 bg-black/10 backdrop-blur-sm rounded-lg">
                <DollarSign className="w-5 h-5 text-neutral-900" />
              </div>
              <span className="text-sm font-bold text-neutral-900/70">Grand Total</span>
            </div>
            <p className="text-4xl font-extrabold tracking-tight">{formatCurrency(estimate.grandTotal)}</p>
          </div>
        </div>

        {/* Market Trends Section */}
        {marketTrends.length > 0 && (
          <div className="mb-8">
            <h3 className="text-sm font-bold text-neutral-400 uppercase tracking-wide mb-3 flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-emerald-500" /> Market Price Trends (Estimated)
            </h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {marketTrends.map((item, idx) => (
                <div key={idx} className="bg-neutral-800/50 border border-neutral-700 rounded-lg p-3 flex items-center justify-between hover:border-neutral-600 transition-colors">
                  <div>
                    <p className="text-xs text-neutral-400 font-medium mb-1">{item.category}</p>
                    <div className="flex items-center gap-1.5">
                      {item.type === 'up' && <TrendingUp className="w-4 h-4 text-red-500" />}
                      {item.type === 'down' && <TrendingDown className="w-4 h-4 text-emerald-500" />}
                      {item.type === 'stable' && <Minus className="w-4 h-4 text-yellow-500" />}
                      <span className={`text-sm font-bold ${
                        item.type === 'up' ? 'text-red-400' : 
                        item.type === 'down' ? 'text-emerald-400' : 'text-yellow-500'
                      }`}>
                        {item.type === 'stable' ? 'Stable' : `${item.percentage}%`}
                      </span>
                    </div>
                  </div>
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center bg-neutral-900 border ${
                    item.type === 'up' ? 'border-red-500/20 text-red-500' : 
                    item.type === 'down' ? 'border-emerald-500/20 text-emerald-500' : 'border-yellow-500/20 text-yellow-500'
                  }`}>
                    <DollarSign className="w-4 h-4" />
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
        
        <div className="mt-8 pt-6 border-t border-neutral-800 -mx-6 -mb-6 px-6 pb-6 bg-neutral-900/50">
          <h3 className="text-sm font-bold text-yellow-500 uppercase tracking-wide mb-3 flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-yellow-500 animate-pulse"></span>
            AI Analysis Summary
          </h3>
          <p className="text-neutral-300 leading-relaxed text-sm bg-neutral-800 p-4 rounded-lg border border-neutral-700 shadow-inner">
            {estimate.summary}
          </p>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-neutral-800 mb-6 gap-6">
        <button
          onClick={() => setActiveTab('summary')}
          className={`pb-3 text-sm font-semibold border-b-2 transition-all ${
            activeTab === 'summary' 
              ? 'border-yellow-500 text-yellow-500' 
              : 'border-transparent text-neutral-500 hover:text-neutral-300'
          }`}
        >
          Visual Analytics
        </button>
        <button
          onClick={() => setActiveTab('materials')}
          className={`pb-3 text-sm font-semibold border-b-2 transition-all ${
            activeTab === 'materials' 
              ? 'border-yellow-500 text-yellow-500' 
              : 'border-transparent text-neutral-500 hover:text-neutral-300'
          }`}
        >
          Bill of Materials
        </button>
      </div>

      {/* Tab Content */}
      <div className="animate-fade-in-up">
        {activeTab === 'summary' && (
          <CostChart estimate={estimate} />
        )}

        {activeTab === 'materials' && (
          <div className="bg-neutral-900 rounded-xl shadow-lg border border-neutral-800 overflow-hidden">
            {/* Filter Header */}
            <div className="p-4 border-b border-neutral-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-neutral-900/50">
               <div className="flex items-center gap-2">
                  <h3 className="text-white font-bold">Detailed Breakdown</h3>
                  <span className="text-xs px-2 py-0.5 rounded-full bg-neutral-800 text-neutral-400 border border-neutral-700">
                    {filteredItems.length} items
                  </span>
               </div>
               
               <div className="flex items-center gap-2">
                 <Filter className="w-4 h-4 text-purple-400" />
                 <select 
                   value={filterCategory}
                   onChange={(e) => setFilterCategory(e.target.value)}
                   className="bg-neutral-950 text-neutral-200 text-sm border border-neutral-700 rounded-lg px-3 py-2 focus:ring-1 focus:ring-purple-500 focus:border-purple-500 outline-none cursor-pointer"
                 >
                   {uniqueCategories.map(cat => (
                     <option key={cat} value={cat}>{cat === 'All' ? 'All Categories' : cat}</option>
                   ))}
                 </select>
               </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-sm text-left">
                <thead className="bg-neutral-950 text-neutral-400 font-semibold border-b border-neutral-800">
                  <tr>
                    <th className="px-6 py-4">Item Name</th>
                    <th className="px-6 py-4">Category</th>
                    <th className="px-6 py-4 text-right">Quantity</th>
                    <th className="px-6 py-4 text-right">Unit Price</th>
                    <th className="px-6 py-4 text-right">Total</th>
                    <th className="px-6 py-4">Confidence</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-neutral-800">
                  {filteredItems.map((item) => {
                    const display = getItemDisplay(item);
                    const hasAlternates = item.alternates && item.alternates.length > 0;
                    const maxOptions = 1 + (item.alternates ? item.alternates.length : 0);

                    return (
                      <tr key={item.id} className="hover:bg-neutral-800/50 transition-colors">
                        <td className="px-6 py-4 font-medium text-neutral-200">
                          {item.name}
                          {item.notes && <p className="text-xs text-neutral-500 mt-1">{item.notes}</p>}
                        </td>
                        <td className="px-6 py-4">
                          <span className="inline-block px-2.5 py-1 rounded-full bg-neutral-800 text-neutral-400 border border-neutral-700 text-xs font-semibold">
                            {item.category}
                          </span>
                        </td>
                        <td className="px-6 py-4 text-right">
                          <div className="flex flex-col items-end gap-1">
                            <div className="flex items-center justify-end gap-2">
                               <span className="text-yellow-500 font-mono text-base">
                                 {display.qty.toLocaleString()}
                               </span>
                               <span className="text-neutral-400 text-xs font-sans uppercase tracking-wider">
                                 {display.unit}
                               </span>
                            </div>
                            {hasAlternates && (
                               <button 
                                 onClick={() => toggleUnit(item.id, maxOptions)}
                                 className="flex items-center gap-1.5 px-2 py-1 bg-neutral-800 hover:bg-neutral-700 border border-neutral-700 rounded-md text-[10px] font-medium text-blue-400/80 hover:text-blue-400 transition-colors"
                                 title="Switch Unit (e.g., Trips ↔ m³)"
                               >
                                 <ArrowLeftRight className="w-3 h-3" />
                                 <span>Switch Unit</span>
                               </button>
                            )}
                          </div>
                        </td>
                        <td className="px-6 py-4 text-right text-neutral-400 font-mono">
                          {formatCurrency(display.price)}
                        </td>
                        <td className="px-6 py-4 text-right font-bold text-white font-mono">
                          {formatCurrency(item.totalPrice)}
                        </td>
                        <td className="px-6 py-4">
                          <div className="flex items-center gap-1.5">
                            <div className={`w-2.5 h-2.5 rounded-full ${
                              item.confidence === 'High' ? 'bg-emerald-500 shadow-lg shadow-emerald-500/20' : 
                              item.confidence === 'Medium' ? 'bg-yellow-500 shadow-lg shadow-yellow-500/20' : 'bg-red-500 shadow-lg shadow-red-500/20'
                            }`}></div>
                            <span className="text-xs text-neutral-500">{item.confidence}</span>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                  {filteredItems.length === 0 && (
                     <tr>
                       <td colSpan={6} className="px-6 py-8 text-center text-neutral-500">
                         No items found in this category.
                       </td>
                     </tr>
                  )}
                </tbody>
              </table>
            </div>
            <div className="p-4 bg-yellow-500/5 border-t border-neutral-800 text-xs text-yellow-600 flex items-start gap-2">
              <AlertTriangle className="w-4 h-4 text-yellow-500 shrink-0" />
              <p>Prices are estimates based on Ghanaian regional averages. Material costs can fluctuate daily. Use the 'Switch Unit' button to view alternatives (e.g. Trips vs m³) where available.</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default EstimateResult;