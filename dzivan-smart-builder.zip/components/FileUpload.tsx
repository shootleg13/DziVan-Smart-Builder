import React, { useCallback, useState } from 'react';
import { Upload, AlertCircle, Files } from 'lucide-react';

interface FileUploadProps {
  onFilesSelected: (files: File[]) => void;
  isProcessing: boolean;
  compact?: boolean;
}

const FileUpload: React.FC<FileUploadProps> = ({ onFilesSelected, isProcessing, compact = false }) => {
  const [dragActive, setDragActive] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleFiles = useCallback((files: FileList) => {
    const validFiles: File[] = [];
    const validTypes = ['image/jpeg', 'image/png', 'image/webp', 'application/pdf'];
    let hasError = false;

    Array.from(files).forEach(file => {
      if (!validTypes.includes(file.type)) {
        setError("Skipped invalid file(s). Please upload images or PDFs.");
        hasError = true;
        return;
      }
      if (file.size > 10 * 1024 * 1024) {
        setError(`Skipped ${file.name} (Too large, max 10MB).`);
        hasError = true;
        return;
      }
      validFiles.push(file);
    });

    if (!hasError) setError(null);
    if (validFiles.length > 0) {
      onFilesSelected(validFiles);
    }
  }, [onFilesSelected]);

  const handleDrag = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      handleFiles(e.dataTransfer.files);
    }
  }, [handleFiles]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    e.preventDefault();
    if (e.target.files && e.target.files.length > 0) {
      handleFiles(e.target.files);
    }
    // Reset input value to allow selecting same file again if needed
    e.target.value = '';
  };

  return (
    <div className="w-full">
      <div 
        className={`relative border-2 border-dashed rounded-2xl text-center transition-all duration-300 ease-in-out group overflow-hidden
          ${dragActive 
            ? 'border-transparent ring-2 ring-yellow-500 bg-neutral-800 scale-[1.02]' 
            : 'border-neutral-700 hover:border-neutral-600 bg-neutral-900 hover:bg-neutral-800'}
          ${compact ? 'p-4' : 'p-10'}
        `}
        onDragEnter={handleDrag}
        onDragLeave={handleDrag}
        onDragOver={handleDrag}
        onDrop={handleDrop}
      >
        {/* Colorful Gradient Border for Active State */}
        {dragActive && (
          <div className="absolute inset-0 bg-gradient-to-r from-blue-500 via-purple-500 to-yellow-500 opacity-20 pointer-events-none"></div>
        )}

        <input 
          type="file" 
          id="file-upload-compact" 
          className="hidden" 
          accept="image/*,application/pdf"
          onChange={handleChange}
          disabled={isProcessing}
          multiple
        />
        <label 
          htmlFor="file-upload-compact" 
          className={`cursor-pointer flex flex-col items-center justify-center relative z-10 ${isProcessing ? 'cursor-not-allowed opacity-50' : ''}`}
        >
          <div className={`
            bg-neutral-800 border border-neutral-700 rounded-full transition-transform group-hover:scale-110 duration-300 shadow-xl
            ${dragActive ? 'scale-110 shadow-yellow-500/20 border-yellow-500' : ''} 
            ${compact ? 'p-2 mb-2' : 'p-5 mb-5'}
          `}>
            {compact ? (
               <Files className="w-5 h-5 text-yellow-500" />
            ) : (
               <Upload className={`w-10 h-10 ${dragActive ? 'text-yellow-400' : 'text-yellow-500'}`} />
            )}
          </div>
          <h3 className={`font-bold text-neutral-200 mb-2 ${compact ? 'text-xs' : 'text-xl'}`}>
            {compact ? 'Add More Plans' : 'Upload Site Plans'}
          </h3>
          {!compact && (
            <p className="text-neutral-500 max-w-sm mx-auto text-sm mb-8 group-hover:text-neutral-400 transition-colors">
              Drag & drop architectural drawings (Image/PDF). Upload multiple files to create a combined estimate.
            </p>
          )}
          {!compact && (
            <div className="flex gap-2">
              <span className="px-3 py-1 bg-neutral-800 border border-neutral-700 text-xs font-semibold text-blue-400 rounded-lg">JPG</span>
              <span className="px-3 py-1 bg-neutral-800 border border-neutral-700 text-xs font-semibold text-purple-400 rounded-lg">PNG</span>
              <span className="px-3 py-1 bg-neutral-800 border border-neutral-700 text-xs font-semibold text-red-400 rounded-lg">PDF</span>
            </div>
          )}
        </label>
      </div>

      {error && (
        <div className="mt-4 p-4 bg-red-900/20 border border-red-900/50 rounded-xl flex items-start gap-3 animate-fade-in">
          <AlertCircle className="w-5 h-5 text-red-500 shrink-0 mt-0.5" />
          <p className="text-sm text-red-400 font-medium">{error}</p>
        </div>
      )}
    </div>
  );
};

export default FileUpload;