export interface AlternateUnit {
  quantity: number;
  unit: string;
  unitPrice: number;
}

export interface MaterialItem {
  id: string;
  category: string;
  name: string;
  quantity: number;
  unit: string;
  unitPrice: number;
  totalPrice: number;
  confidence: string; // 'High' | 'Medium' | 'Low'
  notes?: string;
  alternates?: AlternateUnit[]; // Optional list of other units (e.g. m3 vs Trips)
}

export interface ProjectEstimate {
  projectName: string;
  location: string;
  currency: string;
  items: MaterialItem[];
  laborCostEstimate: number;
  totalMaterialCost: number;
  grandTotal: number;
  summary: string;
}

export enum AppState {
  IDLE = 'IDLE',
  ANALYZING = 'ANALYZING',
  RESULTS = 'RESULTS',
  ERROR = 'ERROR'
}

export interface AnalysisError {
  message: string;
  details?: string;
}

export interface BatchItem {
  id: string;
  file: File;
  status: 'pending' | 'analyzing' | 'completed' | 'error';
  estimate?: ProjectEstimate;
  error?: string;
}