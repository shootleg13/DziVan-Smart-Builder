import React, { useState, useMemo } from 'react';
import { HardHat, LayoutDashboard, Calculator, CheckCircle2, FileText, Loader2, AlertCircle, PlusCircle, PieChart, Trash2, Globe, Menu, X } from 'lucide-react';
import FileUpload from './components/FileUpload';
import EstimateResult from './components/EstimateResult';
import { analyzeSitePlan } from './services/gemini';
import { AppState, ProjectEstimate, BatchItem, MaterialItem } from './types';

const App: React.FC = () => {
  const [batchItems, setBatchItems] = useState<BatchItem[]>([]);
  const [selectedTab, setSelectedTab] = useState<string>('overview');
  const [location, setLocation] = useState<string>('Accra, Ghana');
  const [appState, setAppState] = useState<AppState>(AppState.IDLE);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  // Helper to convert file to base64
  const fileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => {
        const result = reader.result as string;
        const base64 = result.split(',')[1];
        resolve(base64);
      };
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
  };

  const processBatchQueue = async (items: BatchItem[]) => {
    const queue = items.filter(i => i.status === 'pending');
    
    // Process strictly one by one to avoid rate limits or state race conditions for now
    for (const item of queue) {
      // Update status to analyzing
      setBatchItems(prev => prev.map(i => i.id === item.id ? { ...i, status: 'analyzing' } : i));

      try {
        const base64 = await fileToBase64(item.file);
        const result = await analyzeSitePlan(base64, item.file.type, location, item.file.name);
        
        setBatchItems(prev => prev.map(i => i.id === item.id ? { 
          ...i, 
          status: 'completed', 
          estimate: result 
        } : i));
      } catch (err: any) {
        setBatchItems(prev => prev.map(i => i.id === item.id ? { 
          ...i, 
          status: 'error', 
          error: err.message || "Analysis failed" 
        } : i));
      }
    }
  };

  const handleFilesSelect = (files: File[]) => {
    const newItems: BatchItem[] = files.map(file => ({
      id: Math.random().toString(36).substring(7),
      file,
      status: 'pending'
    }));

    setBatchItems(prev => {
      const updated = [...prev, ...newItems];
      setTimeout(() => processBatchQueue(updated), 0);
      return updated;
    });

    setAppState(AppState.RESULTS);
    // On mobile, keep sidebar closed initially or open it if it's the first file? 
    // Usually better to show results immediately.
    setIsSidebarOpen(false); 
  };

  const removeBatchItem = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setBatchItems(prev => {
      const updated = prev.filter(i => i.id !== id);
      if (updated.length === 0) setAppState(AppState.IDLE);
      return updated;
    });
    if (selectedTab === id) setSelectedTab('overview');
  };

  const consolidatedEstimate = useMemo((): ProjectEstimate | null => {
    const completedItems = batchItems.filter(i => i.status === 'completed' && i.estimate);
    if (completedItems.length === 0) return null;

    // Use currency from first item
    const baseCurrency = completedItems[0].estimate!.currency;

    const allItems: MaterialItem[] = [];
    let totalMaterial = 0;
    let totalLabor = 0;
    let grandTotal = 0;

    completedItems.forEach(item => {
      const est = item.estimate!;
      // Tag items with their source file name for clarity in the merged table
      const taggedItems = est.items.map(m => ({
        ...m,
        notes: m.notes ? `${m.notes} (Source: ${est.projectName})` : `Source: ${est.projectName}`
      }));
      
      allItems.push(...taggedItems);
      totalMaterial += est.totalMaterialCost;
      totalLabor += est.laborCostEstimate;
      grandTotal += est.grandTotal;
    });

    return {
      projectName: "Consolidated Project Estimate",
      location: location,
      currency: baseCurrency,
      items: allItems,
      laborCostEstimate: totalLabor,
      totalMaterialCost: totalMaterial,
      grandTotal: grandTotal,
      summary: `Consolidated estimate for ${completedItems.length} architectural drawings/plans. Covers materials and labor for: ${completedItems.map(i => i.estimate?.projectName).join(', ')}.`
    };
  }, [batchItems, location]);

  const activeEstimate = selectedTab === 'overview' 
    ? consolidatedEstimate 
    : batchItems.find(i => i.id === selectedTab)?.estimate;

  const toggleSidebar = () => setIsSidebarOpen(!isSidebarOpen);

  return (
    <div className="min-h-screen bg-neutral-950 flex flex-col font-sans text-neutral-100 relative selection:bg-yellow-500/30">
      
      {/* Background Ambience */}
      <div className="fixed inset-0 pointer-events-none z-0">
         <div className="absolute top-0 left-1/4 w-[500px] h-[500px] bg-purple-900/20 rounded-full blur-[100px] opacity-30"></div>
         <div className="absolute bottom-0 right-1/4 w-[500px] h-[500px] bg-blue-900/20 rounded-full blur-[100px] opacity-30"></div>
      </div>

      {/* Navigation */}
      <nav className="bg-neutral-900/90 backdrop-blur-md border-b border-neutral-800 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center gap-3">
              {/* Mobile Menu Button */}
              {appState === AppState.RESULTS && (
                <button 
                  onClick={toggleSidebar}
                  className="lg:hidden p-2 -ml-2 text-neutral-400 hover:text-white rounded-lg active:bg-neutral-800"
                >
                  <Menu className="w-6 h-6" />
                </button>
              )}

              <div className="flex items-center gap-3 cursor-pointer" onClick={() => setAppState(AppState.IDLE)}>
                <div className="bg-gradient-to-br from-yellow-500 to-amber-600 p-2 rounded-lg shadow-lg shadow-yellow-500/20">
                  <HardHat className="w-6 h-6 text-neutral-900" />
                </div>
                <div>
                  <h1 className="text-xl font-bold tracking-tight text-white">DziVan Smart</h1>
                  <p className="text-[10px] text-yellow-500 font-medium tracking-wide leading-none">AI CONSTRUCTION ESTIMATOR</p>
                </div>
              </div>
            </div>
            
            <div className="flex items-center gap-4">
               {/* Location Selector */}
               <div className="hidden md:flex items-center bg-neutral-800 rounded-full px-4 py-1.5 border border-neutral-700 focus-within:border-yellow-500/50 transition-colors">
                  <span className="text-xs text-neutral-400 mr-2">Region:</span>
                  <input 
                    type="text" 
                    value={location}
                    onChange={(e) => setLocation(e.target.value)}
                    className="bg-transparent border-none text-sm font-semibold text-yellow-500 focus:outline-none w-32 placeholder-neutral-600"
                  />
               </div>
            </div>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="flex-grow relative z-10 flex h-[calc(100vh-64px)] overflow-hidden">
        {appState === AppState.IDLE ? (
          <div className="w-full overflow-y-auto">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 flex flex-col min-h-full">
              <div className="animate-fade-in-up space-y-12 flex-grow">
                <div className="text-center max-w-3xl mx-auto mt-4 md:mt-12">
                  <h2 className="text-4xl font-extrabold text-white tracking-tight sm:text-6xl mb-6">
                    Build Smarter in <span className="text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 via-orange-500 to-red-500">Ghana</span>
                  </h2>
                  <p className="text-lg text-neutral-400 mb-8 leading-relaxed">
                    Upload your site plans or architectural drawings. DziVan Smart automatically calculates blocks, sand, stones, and compares prices from the local Ghanaian market.
                  </p>
                </div>

                <div className="max-w-2xl mx-auto transform hover:scale-[1.01] transition-transform duration-300">
                   <FileUpload onFilesSelected={handleFilesSelect} isProcessing={false} />
                </div>

                <div className="grid md:grid-cols-3 gap-8 mt-8 text-center pb-20">
                  <div className="bg-neutral-900/50 backdrop-blur p-6 rounded-2xl border border-neutral-800 hover:border-blue-500/30 transition-all hover:bg-neutral-800/80 group">
                    <div className="w-14 h-14 bg-blue-500/10 rounded-2xl flex items-center justify-center mx-auto mb-5 border border-blue-500/20 group-hover:scale-110 transition-transform">
                      <LayoutDashboard className="w-7 h-7 text-blue-500" />
                    </div>
                    <h3 className="font-bold text-xl text-white mb-2">Multi-Plan Support</h3>
                    <p className="text-neutral-500 text-sm group-hover:text-neutral-400 transition-colors">Upload foundation, electrical, and roofing plans separately.</p>
                  </div>
                  <div className="bg-neutral-900/50 backdrop-blur p-6 rounded-2xl border border-neutral-800 hover:border-purple-500/30 transition-all hover:bg-neutral-800/80 group">
                    <div className="w-14 h-14 bg-purple-500/10 rounded-2xl flex items-center justify-center mx-auto mb-5 border border-purple-500/20 group-hover:scale-110 transition-transform">
                      <Calculator className="w-7 h-7 text-purple-500" />
                    </div>
                    <h3 className="font-bold text-xl text-white mb-2">Local Pricing</h3>
                    <p className="text-neutral-500 text-sm group-hover:text-neutral-400 transition-colors">Estimates costs using current market rates in Accra, Kumasi.</p>
                  </div>
                  <div className="bg-neutral-900/50 backdrop-blur p-6 rounded-2xl border border-neutral-800 hover:border-emerald-500/30 transition-all hover:bg-neutral-800/80 group">
                    <div className="w-14 h-14 bg-emerald-500/10 rounded-2xl flex items-center justify-center mx-auto mb-5 border border-emerald-500/20 group-hover:scale-110 transition-transform">
                      <CheckCircle2 className="w-7 h-7 text-emerald-500" />
                    </div>
                    <h3 className="font-bold text-xl text-white mb-2">Detailed BOQ</h3>
                    <p className="text-neutral-500 text-sm group-hover:text-neutral-400 transition-colors">Get accurate calculation of Blocks, Cement, Sand, and Stones.</p>
                  </div>
                </div>
              </div>
              
              {/* Footer */}
              <footer className="mt-8 border-t border-neutral-900 py-8 text-center text-sm text-neutral-600">
                 <p>© {new Date().getFullYear()} DziVan Smart Construction.</p>
              </footer>
            </div>
          </div>
        ) : (
          /* Dashboard Layout */
          <>
            {/* Mobile Backdrop */}
            {isSidebarOpen && (
              <div 
                className="fixed inset-0 bg-black/60 backdrop-blur-sm z-40 lg:hidden"
                onClick={() => setIsSidebarOpen(false)}
              ></div>
            )}

            {/* Sidebar / Navigation Drawer */}
            <aside 
              className={`
                fixed lg:relative inset-y-0 left-0 z-50 w-72 lg:w-80 bg-neutral-900 border-r border-neutral-800 
                transform transition-transform duration-300 ease-in-out shadow-2xl lg:shadow-none flex flex-col
                ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}
              `}
            >
              <div className="p-4 flex items-center justify-between border-b border-neutral-800 bg-neutral-900 sticky top-0 z-30">
                <h2 className="text-xs font-bold text-neutral-500 uppercase tracking-wider">Project Files</h2>
                <button onClick={() => setIsSidebarOpen(false)} className="lg:hidden p-1 text-neutral-400">
                  <X className="w-5 h-5" />
                </button>
              </div>
              
              <div className="p-4 flex-1 overflow-y-auto space-y-2">
                 <button
                    onClick={() => {
                      setSelectedTab('overview');
                      setIsSidebarOpen(false);
                    }}
                    className={`w-full flex items-center gap-3 p-3 rounded-xl transition-all ${
                      selectedTab === 'overview' 
                        ? 'bg-gradient-to-r from-yellow-500/10 to-transparent text-yellow-500 border border-yellow-500/30' 
                        : 'text-neutral-400 hover:bg-neutral-800 hover:text-neutral-200 border border-transparent'
                    }`}
                  >
                    <PieChart className="w-5 h-5 shrink-0" />
                    <div className="text-left">
                      <p className="font-bold text-sm">Consolidated Overview</p>
                      <p className="text-xs opacity-70">{batchItems.length} files loaded</p>
                    </div>
                  </button>

                 <div className="h-px bg-neutral-800 my-2"></div>

                 {batchItems.map((item) => (
                   <div 
                     key={item.id}
                     onClick={() => {
                       setSelectedTab(item.id);
                       setIsSidebarOpen(false);
                     }}
                     className={`group relative flex items-center gap-3 p-2.5 rounded-xl cursor-pointer transition-all border ${
                       selectedTab === item.id 
                         ? 'bg-neutral-800 border-purple-500/50 shadow-md' 
                         : 'bg-neutral-900 border-neutral-800 hover:border-neutral-700 hover:bg-neutral-800'
                     }`}
                   >
                     <div className="shrink-0">
                       {item.status === 'pending' && <div className="w-8 h-8 rounded-full bg-neutral-800 flex items-center justify-center border border-neutral-700"><div className="w-2 h-2 bg-neutral-500 rounded-full" /></div>}
                       {item.status === 'analyzing' && <Loader2 className="w-8 h-8 text-blue-500 animate-spin" />}
                       {item.status === 'completed' && <div className="w-8 h-8 rounded-full bg-emerald-900/30 flex items-center justify-center border border-emerald-500/30"><CheckCircle2 className="w-4 h-4 text-emerald-500" /></div>}
                       {item.status === 'error' && <div className="w-8 h-8 rounded-full bg-red-900/30 flex items-center justify-center border border-red-500/30"><AlertCircle className="w-4 h-4 text-red-500" /></div>}
                     </div>
                     <div className="flex-1 min-w-0">
                       <p className="text-sm font-semibold text-neutral-200 truncate">{item.file.name}</p>
                       <p className="text-xs text-neutral-500 truncate">
                         {item.status === 'completed' 
                           ? (new Intl.NumberFormat('en-GH', { style: 'currency', currency: item.estimate?.currency || 'GHS' }).format(item.estimate?.grandTotal || 0))
                           : item.status.charAt(0).toUpperCase() + item.status.slice(1)
                         }
                       </p>
                     </div>
                     <button 
                       onClick={(e) => removeBatchItem(item.id, e)}
                       className="lg:opacity-0 group-hover:opacity-100 p-1.5 hover:bg-red-900/30 text-neutral-500 hover:text-red-400 rounded-lg transition-all"
                     >
                       <Trash2 className="w-4 h-4" />
                     </button>
                   </div>
                 ))}

                 <div className="mt-4 pt-4 border-t border-neutral-800">
                    <FileUpload compact onFilesSelected={handleFilesSelect} isProcessing={false} />
                 </div>
              </div>
            </aside>

            {/* Main Result Area */}
            <div className="flex-1 overflow-y-auto bg-neutral-950/50 p-4 lg:p-8 w-full">
              {activeEstimate ? (
                <EstimateResult 
                  key={selectedTab} 
                  estimate={activeEstimate} 
                  onReset={() => {
                    setBatchItems([]);
                    setAppState(AppState.IDLE);
                  }} 
                />
              ) : (
                <div className="h-full flex flex-col items-center justify-center text-neutral-500 pb-20">
                   {batchItems.some(i => i.status === 'analyzing' || i.status === 'pending') ? (
                     <div className="text-center">
                       <Loader2 className="w-12 h-12 text-blue-500 animate-spin mx-auto mb-4" />
                       <h3 className="text-lg font-bold text-neutral-200">Analyzing Your Plans...</h3>
                       <p className="text-sm max-w-md mx-auto mt-2 px-4">DziVan AI is calculating blocks, cement, and market rates in Ghana.</p>
                     </div>
                   ) : (
                     <div className="text-center">
                        <FileText className="w-16 h-16 text-neutral-800 mx-auto mb-4" />
                        <p className="px-4">Select a file from the menu to view details or upload more plans.</p>
                     </div>
                   )}
                </div>
              )}
            </div>
          </>
        )}
      </main>
    </div>
  );
};

export default App;