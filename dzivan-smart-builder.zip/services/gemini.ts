import { GoogleGenAI, Type } from "@google/genai";
import { ProjectEstimate } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

// Schema for structured JSON output
const estimateSchema = {
  type: Type.OBJECT,
  properties: {
    projectName: { type: Type.STRING, description: "A creative name for the project phase based on the drawing (e.g. Foundation, Electrical)." },
    location: { type: Type.STRING, description: "Inferred context or generic location used for pricing." },
    currency: { type: Type.STRING, description: "Currency code, e.g., GHS (Ghana Cedis)." },
    laborCostEstimate: { type: Type.NUMBER, description: "Estimated total labor cost for the project." },
    totalMaterialCost: { type: Type.NUMBER, description: "Sum of all material costs." },
    grandTotal: { type: Type.NUMBER, description: "Total estimated project cost including labor." },
    summary: { type: Type.STRING, description: "A brief professional executive summary of the project scope." },
    items: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          category: { type: Type.STRING, description: "Category like 'Concrete', 'Framing', 'Walling', 'Electrical'." },
          name: { type: Type.STRING, description: "Specific material name (e.g., '6-inch Cement Blocks')." },
          quantity: { type: Type.NUMBER, description: "Estimated quantity in the primary unit." },
          unit: { type: Type.STRING, description: "Primary unit of measurement (e.g. 'Trips', 'Pieces')." },
          unitPrice: { type: Type.NUMBER, description: "Estimated local market unit price for the primary unit." },
          totalPrice: { type: Type.NUMBER, description: "quantity * unitPrice" },
          confidence: { type: Type.STRING, description: "Confidence level: High, Medium, Low" },
          notes: { type: Type.STRING, description: "Any specific assumptions made." },
          alternates: {
            type: Type.ARRAY,
            description: "Alternative units for the same item (e.g. convert Trips to m3, or Blocks to m2).",
            items: {
              type: Type.OBJECT,
              properties: {
                quantity: { type: Type.NUMBER },
                unit: { type: Type.STRING },
                unitPrice: { type: Type.NUMBER }
              },
              required: ["quantity", "unit", "unitPrice"]
            }
          }
        },
        required: ["category", "name", "quantity", "unit", "unitPrice", "totalPrice", "confidence"]
      }
    }
  },
  required: ["projectName", "items", "laborCostEstimate", "totalMaterialCost", "grandTotal", "summary"]
};

export const analyzeSitePlan = async (
  base64Data: string, 
  mimeType: string,
  locationContext: string = "Ghana",
  filename: string = ""
): Promise<ProjectEstimate> => {
  
  try {
    const prompt = `
      You are an expert Senior Quantity Surveyor and Construction Estimator familiar with the Ghanaian construction market.
      Analyze the provided architectural drawing, site plan, or construction document.
      
      File Name: ${filename} (Use this to infer the phase of the project).
      
      **SPECIAL INSTRUCTION FOR SITE PLANS & WALLING:**
      If the image is a Site Plan or shows a perimeter:
      1. Estimate the linear perimeter length of the wall.
      2. Calculate the specific materials needed for a standard 6ft - 8ft high wall (plus foundation) using Ghanaian standards.
      3. **You MUST output specific line items for:** 
         - **Blocks:** Total number of 5" or 6" hollow cement blocks. (Approx 13 blocks per m²).
         - **Cement:** Bags (50kg) for mortar and concrete.
         - **Sand:** Volume in 'Trips' (Standard Tipper Truck) AND provide an alternative in 'Cubic Yards' or 'm³'.
         - **Stones/Gravel:** Volume in 'Trips' AND alternative in 'Cubic Yards' or 'm³'.
         - **Iron Rods:** For pillars/columns (in Pieces or Tonnes).

      **General Task:**
      1. Identify all visible construction elements.
      2. If specific dimensions are not readable, use standard industry assumptions based on visual proportions.
      3. Generate a detailed Bill of Quantities (BOQ).
      4. Estimate current market material prices based on the location: ${locationContext}. Use the local currency (GHS).
      5. Include an estimate for labor costs typical for this region.
      
      **UNITS:**
      For bulk materials (Sand, Stones), prefer 'Trips' (Mini, Single Axle, or Double Axle) as the primary unit as it is common in Ghana. Provide metric equivalents (m³) in the 'alternates' field.
      
      Return the data strictly in the requested JSON format.
    `;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: {
        parts: [
          {
            inlineData: {
              data: base64Data,
              mimeType: mimeType
            }
          },
          { text: prompt }
        ]
      },
      config: {
        responseMimeType: "application/json",
        responseSchema: estimateSchema,
        temperature: 0.2, 
      }
    });

    if (!response.text) {
      throw new Error("No response received from Gemini.");
    }

    const data = JSON.parse(response.text) as ProjectEstimate;
    
    // Add IDs for UI handling if missing
    data.items = data.items.map((item, index) => ({
      ...item,
      id: `item-${index}-${Date.now()}`
    }));

    return data;

  } catch (error) {
    console.error("Gemini Analysis Error:", error);
    throw error;
  }
};